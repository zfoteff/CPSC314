Don't forget to run npm install for 
"dependencies": {
    "body-parser": "^1.19.0",
    "ejs": "^3.1.5",
    "express": "^4.17.1",
    "mongodb": "^3.6.3"
  }